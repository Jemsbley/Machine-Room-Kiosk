dbuser = 'remote'
dbpass = 'MILLpassword123'
dbhost = '192.168.86.33'
dbname = 'machinestest'

loginPass = '12345'