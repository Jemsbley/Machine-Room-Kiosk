#!/bin/sh

cd ~
cd Documents/Machining-ID
source env/bin/activate

python keypad.py
